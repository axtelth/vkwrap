# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['vkwrap']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.27.1,<3.0.0']

setup_kwargs = {
    'name': 'vkwrap',
    'version': '0.1.0',
    'description': 'Simple Vk Api Wrapper',
    'long_description': None,
    'author': 'Axtelth',
    'author_email': 'axtelth@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
